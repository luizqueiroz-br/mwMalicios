(function () {
  window.pixelId = "68152876fa7e8334b3647c73";
  var a = document.createElement("script");
  a.setAttribute("async", "");
  a.setAttribute("defer", "");
  a.setAttribute("src", "https://cdn.utmify.com.br/scripts/pixel/pixel.js");
  document.head.appendChild(a);
})();

(function () {
  const script = document.createElement("script");

  script.src = "https://cdn.utmify.com.br/scripts/utms/latest.js";
  script.setAttribute("data-utmify-prevent-xcod-sck", "");
  script.setAttribute("data-utmify-prevent-subids", "");
  script.async = true;
  script.defer = true;

  document.head.appendChild(script);
})();
