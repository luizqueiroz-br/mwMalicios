// UTMIFY, troque o pixel só aqui, belê?
(function () {
  window.pixelId = "686da77165e0081ae0673d53";
  var a = document.createElement("script");
  a.setAttribute("async", "");
  a.setAttribute("defer", "");
  a.setAttribute("src", "https://cdn.utmify.com.br/scripts/pixel/pixel.js");
  document.head.appendChild(a);
})();

(function () {
  const script = document.createElement("script");

  script.src = "https://cdn.utmify.com.br/scripts/utms/latest.js";
  script.setAttribute("data-utmify-prevent-xcod-sck", "");
  script.setAttribute("data-utmify-prevent-subids", "");
  script.async = true;
  script.defer = true;

  document.head.appendChild(script);
})();
